
const express = require('express');
const app = express();
const PORT = 3000;

app.get('/data', (req, res) => {
    res.json({ message: 'Hello from the API!' });
});

app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});
