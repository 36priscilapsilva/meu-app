import React, { useEffect, useState } from 'react';
import { Text, View, Button } from 'react-native';
import * as Location from 'expo-location';

export default function App() {
    const [data, setData] = useState(null);
    const [location, setLocation] = useState(null);
    const [errorMsg, setErrorMsg] = useState(null);

    const fetchData = async () => {
        try {
            const response = await fetch('http://localhost:3000/data');
            const json = await response.json();
            setData(json);
        } catch (error) {
            console.error(error);
        }
    };

    const getLocation = async () => {
        let { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== 'granted') {
            setErrorMsg('Permissão para acessar a localização negada');
            return;
        }

        let location = await Location.getCurrentPositionAsync({});
        setLocation(location);
    };

    useEffect(() => {
        fetchData();
        getLocation();
    }, []);

    return (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            {data ? <Text>{data.message}</Text> : <Text>Carregando...</Text>}
            {errorMsg ? <Text>{errorMsg}</Text> : null}
            {location ? (
                <Text>
                    Localização: {location.coords.latitude}, {location.coords.longitude}
                </Text>
            ) : null}
            <Button title="Recarregar Dados" onPress={fetchData} />
        </View>
    );
}
